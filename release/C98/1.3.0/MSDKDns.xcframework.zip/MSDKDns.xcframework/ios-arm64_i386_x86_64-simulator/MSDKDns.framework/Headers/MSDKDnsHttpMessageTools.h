/**
 * Copyright (c) Tencent. All rights reserved.
 */

@interface MSDKDnsHttpMessageTools : NSURLProtocol

@end
